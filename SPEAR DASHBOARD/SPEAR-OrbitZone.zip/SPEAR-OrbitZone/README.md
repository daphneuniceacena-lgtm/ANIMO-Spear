# 🚀 SPEAR: Orbit Zone

> **Official Organization Management App**  
> Engineering and Robotics Organization  
> De La Salle University – Dasmariñas High School  
> Season 2026

---

## Overview

**SPEAR: Orbit Zone** is a NASA/space-themed iPad app built with SwiftUI for managing the day-to-day operations of the ERO (Engineering and Robotics Organization) of DLSU-Dasmariñas High School. Designed for the 2026 season with a deep-space green-and-white aesthetic.

---

## Features

| Module | Description |
|---|---|
| 🛸 **Mission Control** | Dashboard with live stats, alerts, countdowns, and active tasks |
| 📦 **Parts Inventory** | Track robotic components — quantity, location, and stock status |
| 👩‍🚀 **Crew Manifest** | Full member roster with space-themed titles and positions |
| ✅ **Mission Tasks** | Kanban board (To Do → In Progress → Review → Done) |
| 🏆 **Competition Log** | Track upcoming and completed competitions with rankings |
| 💰 **Budget Control** | Income vs. expense ledger with running balance in ₱ |

---

## Tech Stack

- **Language:** Swift 5.9+
- **Framework:** SwiftUI
- **Target:** iPadOS 17+ (Swift Playgrounds 4+)
- **Architecture:** Single-file SwiftUI app with `ObservableObject` state management

---

## Project Structure

```
SPEAR-OrbitZone/
├── README.md
├── .gitignore
├── CHANGELOG.md
├── LICENSE
└── Sources/
    └── SPEAROrbitZone/
        └── ContentView.swift   ← Main app file (all views, models, store)
```

---

## Getting Started

### Swift Playgrounds (iPad — Recommended)

1. Open **Swift Playgrounds** on your iPad
2. Create a new **App** project
3. Replace the contents of the default Swift file with `Sources/SPEAROrbitZone/ContentView.swift`
4. In your `@main` App entry file, set `ContentView()` as the root:
   ```swift
   import SwiftUI

   @main
   struct SPEARApp: App {
       var body: some Scene {
           WindowGroup {
               ContentView()
           }
       }
   }
   ```
5. Tap ▶️ to run

### Xcode (Mac)

1. Create a new **App** project in Xcode targeting **iPadOS**
2. Copy `ContentView.swift` into your project
3. Add an `@main` App struct (see above) in a separate file
4. Build and run on an iPad simulator or device

---

## Roster — 2026 Season

| Name | Position | Space Title |
|---|---|---|
| Amir Zabihi | President | Commander |
| Lana Fajayo | Vice President & PRO | Flight Director |
| Andrea Escamilla | VP of Creatives & Marketing | Mission Specialist |
| Mikoh Filoteo | VP of Finance & Business | Payload Specialist |
| Denielle Medina | Secretary | Navigation Officer |
| Daphne Acena | Robotics Captain & Research Head | Pilot |
| Matt Pacifico | Software Head | Systems Engineer |
| Aldus Plaus | Projects Head | Ground Control |
| Jaiden Olasiman | Hardware Head | Mission Specialist |
| Prince Sadia | Trainings Head | Navigation Officer |

---

## Design System

| Token | Value |
|---|---|
| Primary Green | `#1ACA66` |
| Dark Green | `#0A8040` |
| Background | `#0A0F0A` |
| Surface | `#111C11` |
| Font | SF Mono (`.monospaced`) |
| Theme | NASA / Deep Space |

---

## Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/your-feature`
3. Commit your changes: `git commit -m "feat: describe your change"`
4. Push to the branch: `git push origin feature/your-feature`
5. Open a Pull Request

---

## License

MIT License — see [`LICENSE`](LICENSE) for details.

---

*Built with 💚 by the ERO of DLSU-Dasmariñas High School · 2026*
