# Changelog

All notable changes to **SPEAR: Orbit Zone** will be documented here.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## [1.0.0] — 2026-04-20

### Added
- Initial release of SPEAR: Orbit Zone
- Mission Control dashboard with live stats and alerts
- Parts Inventory module with status tracking (Available / Low Stock / Out of Stock / Ordered)
- Crew Manifest with full 2026 ERO roster and space-themed titles
- Mission Tasks Kanban board (To Do → In Progress → Review → Done)
- Competition Log with upcoming/completed event tracking
- Budget Control with income/expense ledger in ₱
- NASA/space deep-green theme with star canvas background
- iPad-first SwiftUI layout with NavigationSplitView sidebar
- Add/edit sheets for all modules
- Real-time alerts for low-stock parts and overdue tasks

---

## Upcoming

- [ ] Persistent storage (SwiftData / CloudKit)
- [ ] Member profile photos
- [ ] Push notifications for task due dates
- [ ] Export reports to PDF
- [ ] Dark/light mode toggle
- [ ] iCloud sync across devices
